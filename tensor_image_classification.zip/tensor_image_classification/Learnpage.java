package in.notyouraveragedev.tensor_image_classification;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Learnpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learnpage);
    }
}